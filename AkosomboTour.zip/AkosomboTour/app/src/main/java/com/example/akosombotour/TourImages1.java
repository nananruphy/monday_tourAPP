package com.example.akosombotour;

import android.app.Activity;
import android.os.Bundle;

public class TourImages1 extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tour_images_1);
    }
}
