package com.example.akosombotour;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.fragment.app.ListFragment;

import java.util.ArrayList;
import java.util.HashMap;

public class HotelsFragment extends ListFragment {
    int[] hotelsImage = {R.drawable.adomi, R.drawable.akosombodam, R.drawable.adomi, R.drawable.akosombodam};
    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
    SimpleAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String[] hotelsName = getResources().getStringArray(R.array.hotelsName);
        //MAP
        HashMap<String, String> map = new HashMap<String, String>();

        //FILL
        for (int i = 0; i < hotelsName.length; i++) {
            map = new HashMap<String, String>();
            map.put("HotelsName", hotelsName[i]);
            map.put("HotelsImage", Integer.toString(hotelsImage[i]));

            data.add(map);
        }
        //KEYS IN MAP
        String[] from = {"HotelsName", "HotelsImage"};

        //IDS OF VIEWS
        int[] to = {R.id.textview_Hotels, R.id.imageview_Hotels};

        //ADAPTER
        adapter = new SimpleAdapter(getActivity(), data, R.layout.hotels, from, to);
        setListAdapter(adapter);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> av, View v, int pos,
                                    long id) {
                // TODO Auto-generated method stub

                Toast.makeText(getActivity(), data.get(pos).get("HotelsName"), Toast.LENGTH_SHORT).show();

            }
        });
    }
}


