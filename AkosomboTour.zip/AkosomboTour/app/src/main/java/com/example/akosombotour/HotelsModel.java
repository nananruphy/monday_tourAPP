package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class HotelsModel {
    private final String history;

    public HotelsModel(String history) {
        this.history = history;
    }

    public String getHistory() {
        return history;
    }

    public static ArrayList<HotelsModel> getUsers(Context context) {
        ArrayList<HotelsModel> history = new ArrayList<HotelsModel>();
     /**   history.add(new HotelsModel(getResources().getStringArray(R.array.hotelsName)));
        /**history.add(new HotelsModel(context.getString(R.string.hotels1)));
        history.add(new HotelsModel(context.getString(R.string.hotels2)));
        history.add(new HotelsModel(context.getString(R.string.hotels3)));
**/
        return history;
    }
}
