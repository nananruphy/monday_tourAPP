package com.example.akosombotour;

import android.content.Context;

import java.util.ArrayList;

public class HistoryModel {
    private final String history;

    public HistoryModel(String history) {
        this.history = history;
    }

    public String getHistory() {
        return history;
    }

    public static ArrayList<HistoryModel> getUsers(Context context) {
        ArrayList<HistoryModel> history = new ArrayList<HistoryModel>();
     /**   history.add(new HistoryModel(context.getString(R.string.history_string)));
        history.add(new HistoryModel(context.getString(R.string.history_string1)));
        history.add(new HistoryModel(context.getString(R.string.history_string2)));
        history.add(new HistoryModel(context.getString(R.string.history_string3)));
      **/
        return history;
    }
}
