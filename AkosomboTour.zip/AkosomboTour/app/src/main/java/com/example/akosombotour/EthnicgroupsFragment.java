package com.example.akosombotour;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

import androidx.fragment.app.ListFragment;

import java.util.ArrayList;
import java.util.HashMap;

public class EthnicgroupsFragment extends ListFragment {
    int[] ethnicsgroupsImage = {R.drawable.adomi, R.drawable.akosombodam, R.drawable.adomi, R.drawable.akosombodam, R.drawable.adomi, R.drawable.akosombodam, R.drawable.adomi, R.drawable.akosombodam};
    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
    SimpleAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String[] ethnicsgroupsName = getResources().getStringArray(R.array.ethnicgroupsName);
        //MAP
        HashMap<String, String> map = new HashMap<String, String>();

        //FILL
        for (int i = 0; i < ethnicsgroupsName.length; i++) {
            map = new HashMap<String, String>();
            map.put("EthnicsgroupsName", ethnicsgroupsName[i]);
            map.put("EthnicsgroupsImage", Integer.toString(ethnicsgroupsImage[i]));

            data.add(map);
        }
        //KEYS IN MAP
        String[] from = {"EthnicsgroupsName", "EthnicsgroupsImage"};

        //IDS OF VIEWS
        int[] to = {R.id.textview_Ethnicsgroups, R.id.imageview_Ethnicsgroups};

        //ADAPTER
        adapter = new SimpleAdapter(getActivity(), data, R.layout.ethnicsgroups, from, to);
        setListAdapter(adapter);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> av, View view, int i, long id) {

                if (i == 1) {
                    Toast.makeText(getActivity(), "Ewes are 45.8% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 2) {
                    Toast.makeText(getActivity(), "Adangbes are 28..1% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 3) {
                    Toast.makeText(getActivity(), "Akans are 11.6% of the population", Toast.LENGTH_SHORT).show();
                }
                if (i == 5) {
                    Toast.makeText(getActivity(), "Christianity is the major region with", Toast.LENGTH_SHORT).show();
                }
                if (i == 6) {
                    Toast.makeText(getActivity(), "Islam is the second major region with", Toast.LENGTH_SHORT).show();
                }
                if (i == 7) {
                    Toast.makeText(getActivity(), "The Traditional worshippers are the minority", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}