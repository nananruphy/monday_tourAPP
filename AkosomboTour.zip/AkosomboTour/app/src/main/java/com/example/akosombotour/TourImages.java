package com.example.akosombotour;

import android.app.Activity;
import android.os.Bundle;

public class TourImages extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tour_images);
    }
}
