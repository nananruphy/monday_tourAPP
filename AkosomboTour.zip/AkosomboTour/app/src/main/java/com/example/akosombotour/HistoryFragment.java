package com.example.akosombotour;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.SimpleAdapter;

import androidx.fragment.app.ListFragment;

import java.util.ArrayList;
import java.util.HashMap;

public class HistoryFragment extends ListFragment {
    int[] historyImage = {R.drawable.adomi, R.drawable.akosombodam, R.drawable.adomi, R.drawable.akosombodam};
    ArrayList<HashMap<String, String>> data = new ArrayList<HashMap<String, String>>();
    SimpleAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        String[] historyName = getResources().getStringArray(R.array.historyName);
        //MAP
        HashMap<String, String> map = new HashMap<String, String>();

        //FILL
        for (int i = 0; i < historyName.length; i++) {
            map = new HashMap<String, String>();
            map.put("HistoryName", historyName[i]);
            map.put("HistoryImage", Integer.toString(historyImage[i]));

            data.add(map);
        }
        //KEYS IN MAP
        String[] from = {"HistoryName", "HistoryImage"};

        //IDS OF VIEWS
        int[] to = {R.id.textview_History, R.id.imageview_History};

        //ADAPTER
        adapter = new SimpleAdapter(getActivity(), data, R.layout.history, from, to);
        setListAdapter(adapter);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onStart() {
        // TODO Auto-generated method stub
        super.onStart();

        getListView().setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> av, View view, int i, long id) {
                if (i == 0) {
                    Intent intent = new Intent(view.getContext(), AkosomboHistory.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 1) {
                    Intent intent = new Intent(view.getContext(), AkosomboLocation.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 2) {
                    Intent intent = new Intent(view.getContext(), AkosomboChiefs.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 3) {
                    Intent intent = new Intent(view.getContext(), AkosomboClimate.class);
                    view.getContext().startActivity(intent);
                }
                if (i == 4) {
                    Intent intent = new Intent(view.getContext(), AkosomboPopulation.class);
                    view.getContext().startActivity(intent);
                }

            }
        });
    }
}
