package com.example.akosombotour;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AkosomboChiefs extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.akosombo_cheifs);
    }
}
